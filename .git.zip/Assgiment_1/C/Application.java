package c;
import b.B;
public class Application{
	public static void main(String[] args){
		B bObj = new B();
		bObj.run();		
	}
}