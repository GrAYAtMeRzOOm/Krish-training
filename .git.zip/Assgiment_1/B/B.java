package b;
import a.A;
public class B extends A{
	public void run(){
		System.out.println("B is Running");
	}
}