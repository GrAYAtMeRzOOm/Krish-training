package a;
public class A{
	public void run(){
		System.out.println("A is Running..");
	}
}